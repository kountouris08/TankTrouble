// The "TankTrouble" class.
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import hsa.Console;
import sun.audio.*;
import javax.imageio.*;
import java.io.*;
import java.util.Random;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.*;

public class TankTrouble
{

    static Random rand = new Random ();


    static Console c = new Console (30, 150);
    static InputLoop loop;
    static int t = 1;
    static int level = 0;
    static int turretCount = 1;
    static boolean first = true;
    static boolean second = false;
     static boolean third = false;
    Color background = new Color (192, 192, 192);
    static BufferedImage image = new BufferedImage (c.getWidth (), c.getHeight (), BufferedImage.TYPE_INT_ARGB);
    static Graphics2D graphics = image.createGraphics ();

    public static Image loadImage (String name) throws Exception
    {
	Image img = ImageIO.read (new File (name));
	return img;
    }



    public static void playAudio (String file) throws Exception
    {
	InputStream in = new FileInputStream (file);
	AudioStream as = new AudioStream (in);
	AudioPlayer.player.start (as);
    }





    public static void main (String[] args) throws Exception
    {

	loop = new InputLoop ();
	loop.start ();
	tank.xpos = c.getWidth () / 2 + 100;
	tank.ypos = c.getHeight () / 2 + 200;
	graphics.setColor (Color.black);
	graphics.fillRect (0, 0, 640, 480);
	Image brandpre = loadImage ("brand.png"); //loading the initial rocket
       
	Image brand = brandpre.getScaledInstance (640, 480, Image.SCALE_DEFAULT);
	graphics.drawImage (brand, 0, 0, null);
	c.drawImage (image, 0, 0, null);
	Thread.sleep (4000);

	for (int x = 0 ; x <= 190 ; x++)
	{
	    graphics.setColor (new Color (x, x, x));
	    graphics.fillRect (0, 0, 640, 480);
	    c.drawImage (image, 0, 0, null);
	    Thread.sleep (2);
	}


	//initial scene
	Image backgroundpre = loadImage ("background.jpg"); //loading the initial rocket
	Image background = backgroundpre.getScaledInstance (640, 480, Image.SCALE_DEFAULT);

	Image tankpre = loadImage ("tank.png"); //loading the initial scence
	Image tankimg = tankpre.getScaledInstance (250, 130, Image.SCALE_DEFAULT);

	Image logopre = loadImage ("logo.png"); //loading the initial scence
	Image logo = logopre.getScaledInstance (700, 500, Image.SCALE_DEFAULT);

	Image instructionspre = loadImage ("instructions.png"); //loading the initial scence
	Image instructions = instructionspre.getScaledInstance (600, 500, Image.SCALE_DEFAULT);

	graphics.setColor (new Color (190, 190, 190));
	graphics.fillRect (100, 100, 450, 300);
	graphics.drawImage (logo, 0, -100, null);
	graphics.drawImage (tankimg, 200, 200, null);
	graphics.drawImage (instructions, 75, 200, null);
	c.drawImage (image, 0, 0, null);
	Thread.sleep (100);


	graphics.drawImage (background, 0, 0, null);
	graphics.setColor (new Color (190, 190, 190));
	graphics.fillRect (100, 100, 450, 300);
	graphics.drawImage (logo, 0, -100, null);
	graphics.drawImage (tankimg, 200, 200, null);
	c.drawImage (image, 0, 0, null);
	graphics.drawImage (instructions, 75, 200, null);
	c.drawImage (image, 0, 0, null);

	c.getChar ();

	c.clear ();

	wall.Walls.add (new wall (0, 240, 200, 20, 1));
	wall.Walls.add (new wall (200, 140, 20, 120, 0));
	wall.Walls.add (new wall (320, 0, 20, 75, 1));
	wall.Walls.add (new wall (480, 120, 160, 20, 0));
	wall.Walls.add (new wall (540, 300, 100, 20, 0));
	wall.Walls.add (new wall (380, 250, 20, 260, 1));
	wall.Walls.add (new wall (280, 360, 100, 20, 0));
	wall.Walls.add (new wall (120, 360, 20, 140, 1));
	wall.Walls.add (new wall (1070, 0, 20, 75, 1));
	wall.Walls.add (new wall (1060, 240, 300, 20, 0));
	wall.Walls.add (new wall (1060, 240, 20, 170, 1));
	wall.Walls.add (new wall (920, 0, 20, 100, 1));
	wall.Walls.add (new wall (920, 0, 160, 20, 0));
	wall.Walls.add (new wall (800, 250, 150, 20, 0));
	wall.Walls.add (new wall (800, 250, 20, 260, 1));
	wall.Walls.add (new wall (700, 300, 100, 20, 0));
	wall.Walls.add (new wall (720, 0, 20, 125, 1));
	wall.Walls.add (new wall (800, 390, 125, 20, 0));
	wall.Walls.add (new wall (1120, 170, 20, 75, 1));

	wall.Walls.add (new wall (0, 0, c.getWidth (), 20, 0));
	wall.Walls.add (new wall (c.getWidth () - 20, 0, c.getWidth (), c.getHeight (), 1));
	wall.Walls.add (new wall (0, c.getHeight () - 20, c.getWidth (), 20, 0));
	wall.Walls.add (new wall (0, 0, 20, c.getHeight (), 1));

	while (true)
	{


	    drawBackground ();
	    tank.moveTank ();
	    tank.drawTank ();
	    Bullet.update ();
	    wall.drawWalls ();
	    Turret.update ();
	    if (first)
	    {
		first = false;
		for (int i = 0 ; i < 1 ; i++)
		{
		    int x = (int) (Math.random () * 1000);
		    int y = (int) (Math.random () * 600);
		    int a = (int) (Math.random () * Math.PI * 2);
		    Turret.turret.add (new Turret (x, y, a));
		    turretCount = 1;
		    level = 1;
		}

	    }
	    if (second)
	    {
		second = false;
		for (int i = 0 ; i < 2 ; i++)
		{
		    int x = (int) (Math.random () * 1000);
		    int y = (int) (Math.random () * 600);
		    int a = (int) (Math.random () * Math.PI * 2);
		    Turret.turret.add (new Turret (x, y, a));
		    level = 2;
		    turretCount = 2;
		}

	    }
	    if (third)
	    {
		third = false;
		for (int i = 0 ; i < 3 ; i++)
		{
		    int x = (int) (Math.random () * 1000);
		    int y = (int) (Math.random () * 600);
		    int a = (int) (Math.random () * Math.PI * 2);
		    Turret.turret.add (new Turret (x, y, a));
		    level = 3;
		    turretCount = 3;
		}

	    }


	    if (tank.active == false)
	    {
		graphics.drawString ("GAME OVER", c.getWidth () / 2 - 30, c.getHeight () / 2 - 20);
	    }
	    graphics.drawString (String.valueOf (level), c.getWidth () / 2 - 30, c.getHeight () / 2 - 30);
	    c.drawImage (TankTrouble.image, 0, 0, null);
	    try
	    {
		Thread.sleep (t);


	    }
	    catch (Exception ex)
	    {

	    }
	}

	// Place your program here.  'c' is the output console
    } // main method


    public static void drawBackground ()
    {
	Color background = new Color (230, 230, 230);
	graphics.setColor (background);
	graphics.fillRect (0, 0, TankTrouble.c.getWidth (), TankTrouble.c.getHeight ());
    }






} // TankTrouble class

class tank
{

    public static double xpos;
    public static double ypos;
    public static double angle = Math.PI / 2;
    public static int bulletCount = 0;
    public static boolean active = true;




    public static void moveTank  () throws Exception
    {


	switch (TankTrouble.loop.CurrentKey)
	{
	    case 'w':
		if (wallCollide (1) == false)
		{
		    xpos = xpos + (float) Math.cos (angle) * 10;
		    ypos = ypos + (float) Math.sin (angle) * 10;
		    keystop (10);
		}
		break;
	    case 's':
		if (wallCollide (-1) == false)
		{
		    xpos = xpos - (float) Math.cos (angle) * 10;
		    ypos = ypos - (float) Math.sin (angle) * 10;
		    keystop (10);
		}
		break;
	    case 'a':

		angle -= 0.1;
		keystop (10);
		break;

	    case 'd':
		angle += 0.1;
		keystop (10);
		break;

	    case 'q':
		fire ();
		keystop (20);

		break;

	    default:
		break;

	}
    }


    public static void drawTank () throws Exception
    {
	if (tank.active)
	{
	    Image tank = TankTrouble.loadImage ("greenTank.png");
	    Image tankNew = tank.getScaledInstance (75, 35, Image.SCALE_DEFAULT);
	    AffineTransform backup = TankTrouble.graphics.getTransform ();
	    TankTrouble.graphics.setTransform (AffineTransform.getRotateInstance (angle, xpos + 37.5, ypos + 17.5));
	    TankTrouble.graphics.drawImage (tankNew, (int) xpos, (int) ypos, null);
	    TankTrouble.graphics.setTransform (backup);
	}
    }


    public static void fire () throws Exception 
    {
	if (bulletCount <= 5)
	{
	    TankTrouble.playAudio ("Pew_Pew.wav");
	    Bullet.Bullets.add (new Bullet ((int) (tank.xpos + 37.5), (int) (tank.ypos + 17.5), tank.angle, 100, false));
	    bulletCount++;
	}
    }




    public static void keystop (int time)
    {
	for (int x = 0 ; x < time ; x++)
	{
	    //Thread.sleep(10);
	}
	InputLoop.CurrentKey = 'f';
    }


    public static boolean wallCollide (int dir)
    {
	int xnew = (int) (xpos + Math.cos (angle) * 10 * dir);
	int ynew = (int) (ypos + Math.sin (angle) * 10 * dir);

	for (Iterator rowIterator = wall.Walls.iterator () ; rowIterator.hasNext () ;)
	{
	    wall row = (wall) rowIterator.next ();
	    if (xpos < row.x1 || ypos < row.y1)
	    {
		if ((row.y1 <= ynew + 35 && row.y1 + row.y2 >= ynew + 35) && (row.x1 <= xnew + 70 && row.x1 + row.x2 >= xnew + 70))
		{
		    return true;
		}
	    }
	    else
	    {
		if ((row.y1 <= ynew && row.y1 + row.y2 >= ynew) && (row.x1 <= xnew && row.x1 + row.x2 >= xnew))
		{
		    return true;
		}
	    }
	}
	return false;
    }
}

class InputLoop implements Runnable
{
    private Thread t;
    public static char CurrentKey;
    private static char cachedKey;


    public void run ()
    {
	CurrentKey = 'y';
	while (true)
	{

	    cachedKey = TankTrouble.c.getChar ();
	    if (cachedKey == 'w')
	    {

		CurrentKey = cachedKey;

	    }
	    if (cachedKey == 's')
	    {

		CurrentKey = cachedKey;

	    }
	    if (cachedKey == 'a')
	    {

		CurrentKey = cachedKey;

	    }
	    if (cachedKey == 'd')
	    {
		CurrentKey = cachedKey;
	    }
	    if (cachedKey == 'q')
	    {
		CurrentKey = cachedKey;
	    }
	}
    }


    public void start ()
    {
	if (t == null)
	{
	    t = new Thread (this, "InputLoop");
	    t.start ();
	}
    }
}

class Bullet
{
    static ArrayList Bullets = new ArrayList ();
    int xpos;
    int ypos;
    double angle;
    int xnew;
    int ynew;
    int life = 100;
    int number = 0;
    static int count = 0;
    boolean turret;

    public Bullet (int xinit, int yinit, double ainit, int life_, boolean turret_)
    {
	xpos = xinit;
	ypos = yinit;
	angle = ainit;
	life = life_;
	number = count;
	count++;
	turret = turret_;


    }





    public static void update () throws Exception
    {
	ArrayList r = new ArrayList ();
	for (Iterator rowIterator = Bullet.Bullets.iterator () ; rowIterator.hasNext () ;)
	{

	    Bullet row = (Bullet) rowIterator.next ();

	    wallCollide ();
	    tankCollide ();
	    turretCollide ();
	    row.xpos = (int) (row.xpos + (float) Math.cos (row.angle) * 10);


	    row.ypos = (int) (row.ypos + (float) Math.sin (row.angle) * 10);
	    TankTrouble.graphics.setColor (Color.black);
	    TankTrouble.graphics.fillOval (row.xpos, row.ypos, 10, 10);
	    if (row.life <= 0)
	    {
		r.add (row);
		if (row.turret == false)
		{
		    tank.bulletCount--;
		}

	    }
	    row.life--;



	}
	for (Iterator rowIterator = r.iterator () ; rowIterator.hasNext () ;)
	{

	    Bullet row = (Bullet) rowIterator.next ();
	    Bullets.remove (row);
	}

    }


    public static void wallCollide ()
    {

	for (Iterator lisIterator = Bullet.Bullets.iterator () ; lisIterator.hasNext () ;)
	{
	    Bullet lis = (Bullet) lisIterator.next ();
	    int dir;
	    lis.xnew = (int) (lis.xpos + (float) Math.cos (lis.angle) * 10);
	    lis.ynew = (int) (lis.ypos + (float) Math.sin (lis.angle) * 10);
	    for (Iterator rowIterator = wall.Walls.iterator () ; rowIterator.hasNext () ;)
	    {
		wall row = (wall) rowIterator.next ();
		if (lis.xpos < row.x1 || lis.ypos < row.y1)
		{
		    if ((row.y1 <= lis.ynew + 5 && row.y1 + row.y2 >= lis.ynew + 5) && (row.x1 <= lis.xnew + 5 && row.x1 + row.x2 >= lis.xnew + 5))
		    {
			if (row.d == 1)
			{
			    if (lis.xnew - lis.xpos > 0 && lis.ynew - lis.ypos > 0)
			    {

				lis.angle *= -1;
				lis.angle = (Math.PI / 2) - lis.angle;

			    }
			}
		    }
		}
		else
		{
		    if ((row.y1 <= lis.ynew && row.y1 + row.y2 >= lis.ynew) && (row.x1 <= lis.xnew && row.x1 + row.x2 >= lis.xnew))
		    {
			lis.angle -= Math.PI / 2;
		    }
		}
	    }
	}
    }


    public static void turretCollide () throws Exception
    {

	for (Iterator lisIterator = Bullet.Bullets.iterator () ; lisIterator.hasNext () ;)
	{
	    Bullet lis = (Bullet) lisIterator.next ();
	    if (lis.turret == false)
	    {

		for (Iterator rowIterator = Turret.turret.iterator () ; rowIterator.hasNext () ;)
		{
		    Turret row = (Turret) rowIterator.next ();

		    if (Math.sqrt ((lis.xpos - row.xpos) * (lis.xpos - row.xpos) + (lis.ypos - row.ypos) * (lis.ypos - row.ypos)) < 50)

			{

			    row.active = false;
			    TankTrouble.turretCount--;
			    if (TankTrouble.level == 1 && TankTrouble.turretCount == 0)
				TankTrouble.second = true;
			    if (TankTrouble.level == 2 && TankTrouble.turretCount == 0)
				TankTrouble.third = true;
		       
			}

		}
	    }
	}
    }


    public static void tankCollide () throws Exception
    {

	for (Iterator lisIterator = Bullet.Bullets.iterator () ; lisIterator.hasNext () ;)
	{
	    Bullet lis = (Bullet) lisIterator.next ();
	    if (lis.turret == true)
	    {



		if (Math.sqrt ((lis.xpos - tank.xpos) * (lis.xpos - tank.xpos) + (lis.ypos - tank.ypos) * (lis.ypos - tank.ypos)) < 40)

		    {

			tank.active = false;
			TankTrouble.playAudio ("boom.wav");
		    }


	    }
	}
    }
}


class wall
{
    static ArrayList Walls = new ArrayList ();
    int x1;
    int x2;
    int y1;
    int y2;
    int d;
    public wall (int xone, int yone, int xtwo, int ytwo, int dir)
    {
	x1 = xone;
	x2 = xtwo;
	y1 = yone;
	y2 = ytwo;
	d = dir;
    }


    public static void drawWalls ()
    {
	for (Iterator rowIterator = wall.Walls.iterator () ; rowIterator.hasNext () ;)
	{
	    wall row = (wall) rowIterator.next ();
	    Color col = new Color (50, 50, 50);
	    TankTrouble.graphics.setColor (col);
	    TankTrouble.graphics.fillRect (row.x1, row.y1, row.x2, row.y2);

	}
    }
}
class Turret
{
    static ArrayList turret = new ArrayList ();

    double xpos;
    double ypos;
    double angle = Math.PI / 2;
    int bulletCount = 0;
    int Time = 0;
    boolean active = true;



    public Turret (double x, double y, double a) throws Exception
    {
	Image turretImg = TankTrouble.loadImage ("Turret.png");
	Image turretNew = turretImg.getScaledInstance (75, 35, Image.SCALE_DEFAULT);
	xpos = x;
	ypos = y;
	angle = a;
    }


    public static void update () throws Exception
    {
	Image turretImg = TankTrouble.loadImage ("Turret.png");
	Image turretNew = turretImg.getScaledInstance (75, 35, Image.SCALE_DEFAULT);

	for (Iterator rowIterator = Turret.turret.iterator () ; rowIterator.hasNext () ;)

	    {
		Turret row = (Turret) rowIterator.next ();
		if (row.active)
		{


		    AffineTransform backup = TankTrouble.graphics.getTransform ();
		    TankTrouble.graphics.setTransform (AffineTransform.getRotateInstance (row.angle, row.xpos + 37.5, row.ypos + 17.5));
		    TankTrouble.graphics.drawImage (turretNew, (int) row.xpos, (int) row.ypos, null);
		    TankTrouble.graphics.setTransform (backup);

		    if (row.bulletCount <= 10)
		    {

			row.angle = Math.random () * 2 * (Math.PI + 1);

			Bullet.Bullets.add (new Bullet ((int) (row.xpos + 37.5), (int) (row.ypos + 17.5), row.angle, 100, true));
			row.bulletCount++;
			row.Time++;

		    }
		    row.bulletCount++;
		    if (row.bulletCount >= 75)
		    {

			row.bulletCount = 0;
		    }
		}
	    }
    }

















}


